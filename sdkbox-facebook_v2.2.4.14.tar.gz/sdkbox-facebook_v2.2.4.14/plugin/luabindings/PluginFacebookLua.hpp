
#ifndef __PluginFacebookLua_h__
#define __PluginFacebookLua_h__

#ifdef __cplusplus
extern "C" {
#endif
#include "tolua++.h"
#ifdef __cplusplus
}
#endif

int register_all_PluginFacebookLua(lua_State* tolua_S);
















#endif // __PluginFacebookLua_h__
